<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert Inventory</title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>

<?php 
session_start ();
if (isset($_SESSION['username'])) {
	$username= $_SESSION['username'];
}


?>

<a href="inventory.php" class="returnHome"><code>Back</code></a>
<div class="insertBox">
<form action="controller.php" method="post" id="form1">
<label>Inventory Name:</label>
<input type="text" name="name"><br>
<label>Quantity:</label>
<input type="number" name="quantity"><br>
<label>Color:</label>
<input type="color" name="color"><br>
<label>Location:</label>
<input type="text" name="area"><br>
<label>Notes:</label>
<input type="text" name="notes"><br>
<input class="submitButton" type="submit" name="insertInventory" value="Insert">
</form>
</div>

</body>
</html>

