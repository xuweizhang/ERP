<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<title>Order List</title>
</head>

<?php
session_start ();
$login="";

if (isset($_SESSION['loginStatus'])) {
	$login= $_SESSION['loginStatus'];
}

$login = htmlspecialchars($login);

if ($login != "valid"){
	$username = "guest";
} else {
	if(isset($_SESSION['username'])){
		$username= $_SESSION["username"];
		$username = htmlspecialchars($username);
	}
}

?>

<body onload="showAll()" class="customerListBody">

<form action="controller.php" method="post">
<ul class="homeul">
<li><a href="home.php"><code>Home</code></a></li>
<li><a href="customers.php?"><code>Customers</code></a></li>
<li><a href="employees.php?"><code>Employees</code></a></li>
<li><a href="order.php?"><code>Order</code></a></li>
<li><a href="inventory.php?"><code>Inventory</code></a></li>
<li><a href="sales.php?"><code>Sales Report</code></a></li>
<li><a href="purchase.php?"><code>Purchase</code></a></li>
<li style="float:right" id="login"><a href="login.php"><code>Log In</code></a></li>
<li style="float:right" id="signUp"><a href="register.php"><code>Sign Up</code></a></li>
<?php
echo '<li style="float:right" id="username"><a><code>' . $username . '</code></a></li>'
?>
<li style="float:right" id="logout"><a href="controller.php?status=logout"><code id="logout">Log Out</code></a></li>
</ul>
</form>


<button class="addNewOrderButton"><a href="insertOrder.php">+ New Order</a></button>
<hr style="margin-top:6%;border-top: dotted 1px;color:grey;">

<div class="orderTitle">Order of This Month</div>
<div id="thisMonth"></div>
<div class="orderTitle">Order of Next 3 Months</div>
<div id="nextMonth"></div>



<script>
function showAll() {
	// login status
	<?php 
	if ($login == "valid"){
	?>
	    var login = document.getElementById("login");
     	var register = document.getElementById("signUp");
     	login.style.display = "none";
     	register.style.display = "none";
	<?php } else { ?>
		var logout = document.getElementById("logout");
		var username = document.getElementById("username");
		logout.style.display = "none";
     	username.style.display = "none";
	<?php }?>

	
	
	var thisMonth = document.getElementById("thisMonth");
	var nextMonth = document.getElementById("nextMonth");
	
	// display the table of employees
	var display ="";
    display += '<div class="table">';
    
    display += '<div class="row header">';
    display += '<div class="cell">Product Name</div>';
    display += '<div class="cell">Quantity</div>';
    display += '<div class="cell">Unit Price($)</div>';
    display += '<div class="cell">Total($)</div>';
    display += '<div class="cell">Due Date</div>';
    display += '<div class="cell">Build</div>';
    display += '<div class="cell">Ship</div>';
    display += '<div class="cell">Color</div>';
    display += '</div>';

      var ajax = new XMLHttpRequest();
	  ajax.open("GET", "controller.php?type=thisMonthOrder", true);
	  ajax.send(); 
	  ajax.onreadystatechange = function () {
		  if (ajax.readyState == 4 && ajax.status == 200) {
			  var array = JSON.parse(ajax.responseText);
              
			  for (var i=0; i<array.length; i++){
                   display += '<div class="row">';
                   display += '<div class="cell">' + array[i]['name'] + '</div>';
                   display += '<div class="cell">' + array[i]['quantity'] + '</div>';
                   display += '<div class="cell">' + array[i]['price'] + '</div>';
                   display += '<div class="cell">' + array[i]['total'] + '</div>';
                   display += '<div class="cell">' + array[i]['due'] + '</div>';
                   display += '<div class="cell">' + array[i]['build'] + '</div>';
                   display += '<div class="cell">' + array[i]['ship'] + '</div>';
                   display += '<div class="cell">' + array[i]['color'] + '</div>';
                   display += '</div>';
			  }
			  display += '</div>';
			  display += '<hr style="margin-bottom:3%;margin-top:3%;border-top: dotted 1px;color:grey;">';	
			  
			  thisMonth.innerHTML = display;	
		  }
	  }

	// display the table of employees
	    display2 ="";
	    display2 += '<div class="table">';
	    display2 += '<div class="row header">';
	    display2 += '<div class="cell">Product Name</div>';
	    display2 += '<div class="cell">Quantity</div>';
	    display2 += '<div class="cell">Unit Price($)</div>';
	    display2 += '<div class="cell">Total($)</div>';
	    display2 += '<div class="cell">Due Date</div>';
	    display2 += '<div class="cell">Build</div>';
	    display2 += '<div class="cell">Ship</div>';
	    display2 += '<div class="cell">Color</div>';
	    display2 += '</div>';
        
	      var ajax2 = new XMLHttpRequest();
		  ajax2.open("GET", "controller.php?type=nextOrder", true);
		  ajax2.send(); 
		  ajax2.onreadystatechange = function () {
			  if (ajax2.readyState == 4 && ajax2.status == 200) {
				  var array2 = JSON.parse(ajax2.responseText);
	              
				  for (var i=0; i<array2.length; i++){
	                   display2 += '<div class="row">';
	                   display2 += '<div class="cell">' + array2[i]['name'] + '</div>';
	                   display2 += '<div class="cell">' + array2[i]['quantity'] + '</div>';
	                   display2 += '<div class="cell">' + array2[i]['price'] + '</div>';
	                   display2 += '<div class="cell">' + array2[i]['total'] + '</div>';
	                   display2 += '<div class="cell">' + array2[i]['due'] + '</div>';
	                   display2 += '<div class="cell">' + array2[i]['build'] + '</div>';
	                   display2 += '<div class="cell">' + array2[i]['ship'] + '</div>';
	                   display2 += '<div class="cell">' + array2[i]['color'] + '</div>';
	                   display2 += '</div>';
				  }
				  display2 += '</div>';	
				  
				  nextMonth.innerHTML = display2;	
			  }
		  }
}	 
</script>

<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
</body>
</html>
