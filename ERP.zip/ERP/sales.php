<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="stylesheet" href="css/common.css">
<link rel="stylesheet" href="css/03.css">
<title>Sales Report</title>
</head>

<?php
session_start ();
$login="";

if (isset($_SESSION['loginStatus'])) {
	$login= $_SESSION['loginStatus'];
}

$login = htmlspecialchars($login);

if ($login != "valid"){
	$username = "guest";
} else {
	if(isset($_SESSION['username'])){
		$username= $_SESSION["username"];
		$username = htmlspecialchars($username);
	}
}

?>

<body onload="showAll()" class="customerListBody">

<form action="controller.php" method="post">
<ul class="homeul">
<li><a href="home.php"><code>Home</code></a></li>
<li><a href="customers.php?"><code>Customers</code></a></li>
<li><a href="employees.php?"><code>Employees</code></a></li>
<li><a href="order.php?"><code>Order</code></a></li>
<li><a href="inventory.php?"><code>Inventory</code></a></li>
<li><a href="sales.php?"><code>Sales Report</code></a></li>
<li><a href="purchase.php?"><code>Purchase</code></a></li>
<li style="float:right" id="login"><a href="login.php"><code>Log In</code></a></li>
<li style="float:right" id="signUp"><a href="register.php"><code>Sign Up</code></a></li>
<?php
echo '<li style="float:right" id="username"><a><code>' . $username . '</code></a></li>'
?>
<li style="float:right" id="logout"><a href="controller.php?status=logout"><code id="logout">Log Out</code></a></li>
</ul>
</form>

<div id="wrapper">
			<div class="chart">
				<h2>Sales Report in Recent 5 Months</h2>
				<table id="data-table" border="1" cellpadding="10" cellspacing="0">	
					<thead>
						<tr>
							<td>&nbsp;</td>
							<th scope="col"><?php echo date("Y-m", strtotime("-4 month"))?></th>
							<th scope="col"><?php echo date("Y-m", strtotime("-3 month"))?></th>
							<th scope="col"><?php echo date("Y-m", strtotime("-2 month"))?></th>
							<th scope="col"><?php echo date("Y-m", strtotime("-1 month"))?></th>
							<th scope="col"><?php echo date("Y-m")?></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<th scope="row">Tanned Zombie</th>
							<td>1040</td>
							<td>1760</td>
							<td>2880</td>
							<td>4720</td>
							<td>7520</td>
						</tr>
					</tbody>
				</table>
		</div>
</div>		


<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
	
<!-- Grab jQuery from Google -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		
<!-- Example JavaScript -->
	<script src="js/03.js"></script>
</body>
</html>