<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<title>Customers List</title>
</head>

<?php
session_start ();
$login="";

if (isset($_SESSION['loginStatus'])) {
	$login= $_SESSION['loginStatus'];
}

$login = htmlspecialchars($login);

if ($login != "valid"){
	$username = "guest";
} else {
	if(isset($_SESSION['username'])){
		$username= $_SESSION["username"];
		$username = htmlspecialchars($username);
	}
}

?>

<body onload="showAll()" class="customerListBody">

<form action="controller.php" method="post">
<ul class="homeul">
<li><a href="home.php"><code>Home</code></a></li>
<li><a href="customers.php?"><code>Customers</code></a></li>
<li><a href="employees.php?"><code>Employees</code></a></li>
<li><a href="order.php?"><code>Order</code></a></li>
<li><a href="inventory.php?"><code>Inventory</code></a></li>
<li><a href="sales.php?"><code>Sales Report</code></a></li>
<li><a href="purchase.php?"><code>Purchase</code></a></li>
<li style="float:right" id="login"><a href="login.php"><code>Log In</code></a></li>
<li style="float:right" id="signUp"><a href="register.php"><code>Sign Up</code></a></li>
<?php
echo '<li style="float:right" id="username"><a><code>' . $username . '</code></a></li>'
?>
<li style="float:right" id="logout"><a href="controller.php?status=logout"><code id="logout">Log Out</code></a></li>
</ul>
</form>


<button class="addNewCustomerButton"><a href="insertCustomer.php">+ New Customer</a></button>

<form action="search.php?type=customer" method="post"> 
<input type="text" name="searchKey" id="searchBar"> 
<input type="submit" id="searchButton" value="search">
</form>

<div id="allCustomers"></div>

<script>
function showAll() {
	// login status
	<?php 
	if ($login == "valid"){
	?>
	    var login = document.getElementById("login");
     	var register = document.getElementById("signUp");
     	login.style.display = "none";
     	register.style.display = "none";
	<?php } else { ?>
		var logout = document.getElementById("logout");
		var username = document.getElementById("username");
		logout.style.display = "none";
     	username.style.display = "none";
	<?php }?>

	var allCustomers = document.getElementById("allCustomers");

	// display the table of customers
	var display ="";
    display += '<div class="limiter"><div class="container-table100"><div class="wrap-table100"><div class="table">';
    display += '<div class="row header">';
    display += '<div class="cell">Full Name</div>';
    display += '<div class="cell">Company</div>';
    display += '<div class="cell">Job Title</div>';
    display += '<div class="cell">Phone Number</div>';
    display += '<div class="cell">Email</div>';
    display += '<div class="cell">Address</div>';
    display += '</div>';

      var ajax = new XMLHttpRequest();
	  ajax.open("GET", "controller.php?type=customers", true);
	  ajax.send(); 
	  ajax.onreadystatechange = function () {
		  if (ajax.readyState == 4 && ajax.status == 200) {
			  var array = JSON.parse(ajax.responseText);
              
			  for (var i=0; i<array.length; i++){
                   display += '<div class="row">';
                   display += '<div class="cell" data-title ="Full Name">' + array[i]['name'] + '</div>';
                   display += '<div class="cell">' + array[i]['company'] + '</div>';
                   display += '<div class="cell">' + array[i]['title'] + '</div>';
                   display += '<div class="cell">' + array[i]['phone_no'] + '</div>';
                   display += '<div class="cell">' + array[i]['email'] + '</div>';
                   display += '<div class="cell">' + array[i]['address'] + '</div>';
                   display += '</div>';
			  }
			  display += '</div></div></div></div>';	
			  
			  allCustomers.innerHTML = display;	  
		  }
	  }

     
}	 
</script>

<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
</body>
</html>