<?php
//controller.php
session_start();
require_once './DataBaseAdapter.php';
//search
if(isset( $_GET ['searchEmployee'] ) ){
	$employeeName=$_GET ['searchEmployee'];
	$arr = $theDBA->searchEmployee($employeeName);
	echo json_encode($arr);
}

if(isset( $_GET ['searchCustomer'] ) ){
	$customerName=$_GET ['searchCustomer'];
	$arr = $theDBA->searchCustomer($customerName);
	echo json_encode($arr);
}

if(isset( $_GET ['searchPurchase'] ) ){
	$purchaseName=$_GET ['searchPurchase'];
	$arr = $theDBA->searchPurchase($purchaseName);
	echo json_encode($arr);
}

if(isset( $_GET ['searchInventory'] ) ){
	$inventoryName=$_GET ['searchInventory'];
	$arr = $theDBA->searchInventory($inventoryName);
	echo json_encode($arr);
}


//changeRating
elseif (isset ( $_POST ['edit'] ) && isset ( $_POST ['id'] )) {
 $edit = $_POST ['edit'];
 $id = $_POST ['id'];
 if ($edit === 'plus') {
  $theDBA->changeRating ( $id, 1);
 }
 if ($edit === 'minus') {
  $theDBA->changeRating ( $id,-1 );
 }
 header ( "Location: ./movie.php?movieName=".getMovieById($id)[0]['name']);
}
//register.php
elseif (isset ( $_POST ['register'] )) {
 $username = $_POST ["username"];
 $password = $_POST ["password"];
 $existUser = $theDBA -> userCheck($username);
 if ($existUser == true){
  $hash_pwd = password_hash ( $password, PASSWORD_DEFAULT );
  $theDBA->addUser ( $username, $hash_pwd );
  header ( "Location: ./home.php");
 }else{
  $_SESSION["status"]='exist';
  header ( "Location: ./register.php" );
 }
}
//login.php
elseif (isset ($_POST['login'])){
 $username = $_POST ["username"];
 $password = $_POST ["password"];
 $verify = $theDBA -> verifyCredentials($username, $password);
 if ($verify == true){
  $_SESSION["loginStatus"]="valid";
  $_SESSION["username"]=$username;
  if($username == "administer")
  	header ( "Location: ./insert.php");
  else
  	header ( "Location: ./home.php");
 }else {	
	$_SESSION["loginStatus"]='invalid';
	header ( "Location: ./login.php" );
 }
}
//logout function
elseif (isset ($_GET['status'])){
	if($_GET['status'] == 'logout')
 		session_destroy();
 		header ( "Location: ./home.php");
}

//insert.php
//insert customer info:
elseif(isset ($_POST['insertCustomer'])){
	$name=$_POST['name'];
	$company=$_POST['company'];
	$title=$_POST['title'];
	$phone_no=$_POST['phone_no'];
	$email=$_POST['email'];
	$address=$_POST['address'];

	$theDBA->insertCustomer($name, $company, $title, $phone_no, $email, $address);
	$_SESSION["username"]="administer";
	header ( "Location: ./customers.php");
}

elseif(isset ($_POST['insertEmployee'])){
	$name=$_POST['name'];
	$department=$_POST['department'];
	$position=$_POST['position'];
	$phone_no=$_POST['phone_no'];
	$email=$_POST['email'];
	$address=$_POST['address'];

	$theDBA->insertEmployee($name, $department, $position, $phone_no, $email, $address);
	$_SESSION["username"]="administer";
	header ( "Location: ./employees.php");
}

elseif(isset ($_POST['insertOrder'])){
	$name=$_POST['name'];
	$quantity=$_POST['quantity'];
	$price = $_POST['price'];
	$due=$_POST['due'];
	$build=$_POST['build'];
	$ship=$_POST['ship'];
	$color=$_POST['color'];
	
	$q = (int)$quantity;
	$total = $price * $q;

	$theDBA->insertOrder($name, $quantity, $price, $total, $due, $build, $ship, $color);
	$_SESSION["username"]="administer";
	header ( "Location: ./order.php");
}

elseif(isset ($_POST['insertPurchase'])){
	$name=$_POST['name'];
	$quantity=$_POST['quantity'];
	$purchase_date=$_POST['purchase_date'];
	$price=$_POST['price'];
	$status=$_POST['status'];
	
	$q = (int)$quantity;
	$p = (float)$price;
	$total = $p * $q;

	$theDBA->insertPurchase($name, $purchase_date, $quantity, $price, $total, $status);
	$_SESSION["username"]="administer";
	header ( "Location: ./purchase.php");
}

elseif(isset ($_POST['insertInventory'])){
	$name=$_POST['name'];
	$quantity=$_POST['quantity'];
	$color=$_POST['color'];
	$area=$_POST['area'];
	$notes=$_POST['notes'];
	
	$theDBA->insertInventory($name, $quantity, $color, $area, $notes);
	$_SESSION["username"]="administer";
	header ( "Location: ./inventory.php");
}


// get data 
elseif(isset($_GET['type'])&&$_GET['type'] == 'customers'){
	$arr = $theDBA->getAllCustomers();
	echo json_encode($arr);
}

elseif(isset($_GET['type'])&&$_GET['type'] == 'employees'){
	$arr = $theDBA->getAllEmployees();
	echo json_encode($arr);
}

elseif(isset($_GET['type'])&&$_GET['type'] == 'purchase'){
	$arr = $theDBA->getAllPurchase();
	echo json_encode($arr);
}

elseif(isset($_GET['type'])&&$_GET['type'] == 'inventory'){
	$arr = $theDBA->getAllInventory();
	echo json_encode($arr);
}

elseif(isset($_GET['type'])&&$_GET['type'] == 'thisMonthOrder'){
	$from_date = date("Y-m-d");
	$to_date =date("Y-m-d", strtotime("last day of this month"));
	
	$arr = $theDBA->getOrder($from_date, $to_date);
	echo json_encode($arr);
}

elseif(isset($_GET['type'])&&$_GET['type'] == 'nextOrder'){
	$from_date = date("Y-m-d", strtotime("first day of next month"));
	$to_date =date("Y-m-d", strtotime("last day of +2 month"));

	$arr = $theDBA->getOrder($from_date, $to_date);
	echo json_encode($arr);
}

elseif(isset($_GET['type'])&&$_GET['type'] == 'sales'){
	$from_date = date("Y-m-d", strtotime("first day of -4 month"));
	$to_date =date("Y-m-d");

	$arr = $theDBA->getOrder($from_date, $to_date);
	echo json_encode($arr);
}



elseif(isset($_POST['add'])){
	
	
	header ( "Location: ./inventory.php");
}

	
?>