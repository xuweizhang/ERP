<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert Order</title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>

<?php 
session_start ();
if (isset($_SESSION['username'])) {
	$username= $_SESSION['username'];
}


?>

<a href="order.php" class="returnHome"><code>Back</code></a>

<div class="insertOrderBox">
<form action="controller.php" method="post" id="form1">
<label>Product Name:</label>
<input type="text" name="name"><br>
<label>Quantity:</label>
<input type="number" name="quantity"><br>
<label>Unit Price:</label>
<input type="number" step=0.01 name="price"><br>
<label>Due Date:</label>
<input type="date" name="due"><br>
<label>Build:</label>
<input type="radio" name="build" value="Not Started">Not Started<br>
<label></label><input type="radio" name="build" value="Working on it">Working on it<br>
<label></label><input type="radio" name="build" value="Done">Done<br>
<label>Ship:</label>
<input type="radio" name="ship" value="Not Shipped">Not Shipped<br>
<label></label><input type="radio" name="ship" value="On Progress">On Progress<br>
<label></label><input type="radio" name="ship" value="Delivered">Delivered<br>
<label>Color:</label>
<input type="color" name="color"><br><br>
<input class="submitButton" type="submit" name="insertOrder" value="Insert">
</form>
</div>

</body>
</html>

