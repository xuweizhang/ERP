<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert Employee</title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>

<?php 
session_start ();
if (isset($_SESSION['username'])) {
	$username= $_SESSION['username'];
}


?>

<a href="employees.php" class="returnHome"><code>Back</code></a>
<div class="insertBox">
<form action="controller.php" method="post" id="form1">
<label>Full Name:</label>
<input type="text" name="name"><br>
<label>department:</label>
<input type="text" name="department"><br>
<label>Position:</label>
<input type="text" name="position"><br>
<label>Phone Number:</label>
<input type="text" name="phone_no"><br>
<label>Email:</label>
<input type="text" name="email"><br>
<label>Address:</label>
<input type="text" name="address"><br><br>
<input class="submitButton" type="submit" name="insertEmployee" value="Insert">
</form>
</div>

</body>
</html>
