<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<title>Search Result</title>
</head>

<?php
session_start ();
$login="";

if (isset($_SESSION['loginStatus'])) {
	$login= $_SESSION['loginStatus'];
}

$login = htmlspecialchars($login);

if ($login != "valid"){
	$username = "guest";
} else {
	if(isset($_SESSION['username'])){
		$username= $_SESSION["username"];
		$username = htmlspecialchars($username);
	}
}

if (isset($_GET['type'])){
	$type = $_GET['type'];
}


if (isset($_POST['searchKey'])){
	$searchKey = $_POST['searchKey'];
}
?>

<body onload="showAll()" class="customerListBody">

<form action="controller.php" method="post">
<ul class="homeul">
<li><a href="home.php"><code>Home</code></a></li>
<li><a href="customers.php?"><code>Customers</code></a></li>
<li><a href="employees.php?"><code>Employees</code></a></li>
<li><a href="order.php?"><code>Order</code></a></li>
<li><a href="inventory.php?"><code>Inventory</code></a></li>
<li><a href="sales.php?"><code>Sales Report</code></a></li>
<li><a href="purchase.php?"><code>Purchase</code></a></li>
<li style="float:right" id="login"><a href="login.php"><code>Log In</code></a></li>
<li style="float:right" id="signUp"><a href="register.php"><code>Sign Up</code></a></li>
<?php
echo '<li style="float:right" id="username"><a><code>' . $username . '</code></a></li>'
?>
<li style="float:right" id="logout"><a href="controller.php?status=logout"><code id="logout">Log Out</code></a></li>
</ul>
</form>

<?php 
if($_GET['type'] == 'customer'){
	echo '<button class="addNewCustomerButton"><a href="customers.php">Reset</a></button>';
}
else if($_GET['type'] == 'employee'){
	echo '<button class="addNewCustomerButton"><a href="employees.php">Reset</a></button>';
}
if($_GET['type'] == 'purchase'){
	echo '<button class="addNewCustomerButton"><a href="purchase.php">Reset</a></button>';
}


?>



<div id="searchResult"></div>

<script>
function showAll() {
	// login status
	<?php 
	if ($login == "valid"){
	?>
	    var login = document.getElementById("login");
     	var register = document.getElementById("signUp");
     	login.style.display = "none";
     	register.style.display = "none";
	<?php } else { ?>
		var logout = document.getElementById("logout");
		var username = document.getElementById("username");
		logout.style.display = "none";
     	username.style.display = "none";
	<?php }?>

	var searchResult = document.getElementById("searchResult");


    var type = '<?php echo $type; ?>';
    

    if(type == "customer"){
    	var display ="";
        display += '<div class="limiter"><div class="container-table100"><div class="wrap-table100"><div class="table">';
        display += '<div class="row header">';
        display += '<div class="cell">Full Name</div>';
        display += '<div class="cell">Company</div>';
        display += '<div class="cell">Job Title</div>';
        display += '<div class="cell">Phone Number</div>';
        display += '<div class="cell">Email</div>';
        display += '<div class="cell">Address</div>';
        display += '</div>';

          var ajax = new XMLHttpRequest();
    	  ajax.open("GET", "controller.php?searchCustomer=" + '<?php echo $searchKey?>', true);
    	  ajax.send(); 
    	  ajax.onreadystatechange = function () {
    		  if (ajax.readyState == 4 && ajax.status == 200) {
    			  var array = JSON.parse(ajax.responseText);
                  
    			  for (var i=0; i<array.length; i++){
                       display += '<div class="row">';
                       display += '<div class="cell" data-title ="Full Name">' + array[i]['name'] + '</div>';
                       display += '<div class="cell">' + array[i]['company'] + '</div>';
                       display += '<div class="cell">' + array[i]['title'] + '</div>';
                       display += '<div class="cell">' + array[i]['phone_no'] + '</div>';
                       display += '<div class="cell">' + array[i]['email'] + '</div>';
                       display += '<div class="cell">' + array[i]['address'] + '</div>';
                       display += '</div>';
    			  }
    			  display += '</div></div></div></div>';	
    			  
    			  searchResult.innerHTML = display;	  
    		  }
    	  }
    } // type is customer
        
	
	if (type == "employee"){
		
	// display the table of employees
	var display ="";
    display += '<div class="limiter">';
    display += '<div class="container-table100">';
    display += '<div class="wrap-table100"><div class="table">';
    display += '<h3>Search Result</h3>';
    display += '<div class="row header">';  
    display += '<div class="cell">Full Name</div>';
    display += '<div class="cell">Department</div>';
    display += '<div class="cell">Position</div>';
    display += '<div class="cell">Phone Number</div>';
    display += '<div class="cell">Email</div>';
    display += '<div class="cell">Address</div>';
    display += '</div>';

      var ajax = new XMLHttpRequest();
	  ajax.open("GET", "controller.php?searchEmployee=" + '<?php echo $searchKey?>', true);
	  ajax.send(); 
	  ajax.onreadystatechange = function () {
		  if (ajax.readyState == 4 && ajax.status == 200) {
			  var array = JSON.parse(ajax.responseText);
              
			  for (var i=0; i<array.length; i++){
                   display += '<div class="row">';
                   display += '<div class="cell">' + array[i]['name'] + '</div>';
                   display += '<div class="cell">' + array[i]['department'] + '</div>';
                   display += '<div class="cell">' + array[i]['position'] + '</div>';
                   display += '<div class="cell">' + array[i]['phone_no'] + '</div>';
                   display += '<div class="cell">' + array[i]['email'] + '</div>';
                   display += '<div class="cell">' + array[i]['address'] + '</div>';
                   display += '</div>';
			  }
			  display += '</div></div></div></div>';	
			  
			  searchResult.innerHTML = display;	  
		  }
	  }
	} // type is employee    


	if (type == "purchase"){
		// display the table of purchase
		var display ="";
	    display += '<div class="limiter"><div class="container-table100"><div class="wrap-table100"><div class="table">';
	    display += '<div class="row header">';
	    display += '<div class="cell">Purchase Item</div>';
	    display += '<div class="cell">Purchase Date</div>';
	    display += '<div class="cell">Quantity</div>';
	    display += '<div class="cell">Price($)</div>';
	    display += '<div class="cell">Total($)</div>';
	    display += '<div class="cell">Status</div>';
	    display += '</div>';

	      var ajax = new XMLHttpRequest();
		  ajax.open("GET", "controller.php?searchPurchase=" + '<?php echo $searchKey?>', true);
		  ajax.send(); 
		  ajax.onreadystatechange = function () {
			  if (ajax.readyState == 4 && ajax.status == 200) {
				  var array = JSON.parse(ajax.responseText);
	              
				  for (var i=0; i<array.length; i++){
	                   display += '<div class="row">';
	                   display += '<div class="cell">' + array[i]['name'] + '</div>';
	                   display += '<div class="cell">' + array[i]['purchase_date'] + '</div>';
	                   display += '<div class="cell">' + array[i]['quantity'] + '</div>';
	                   display += '<div class="cell">' + array[i]['price'] + '</div>';
	                   display += '<div class="cell">' + array[i]['total'] + '</div>';
	                   display += '<div class="cell">' + array[i]['status'] + '</div>';
	                   display += '</div>';
				  }
				  display += '</div></div></div></div>';	
				  
				  searchResult.innerHTML = display;	  
			  }
		  }

	} // type is purchase  

	
}// showAll


</script>



<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
</body>
</html>