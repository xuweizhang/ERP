<?php
class DatabaseAdaptor {
	private $DB; // The instance variable used in every function
	// Connect to an existing data based named 'imdb_small'
	public function __construct() {
		$db = 'mysql:dbname=ERP; host=127.0.0.1; charset=utf8';
		$user = 'root';
		$password = ''; // an empty string
		try {
			$this->DB = new PDO ( $db, $user, $password );
			$this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		} catch ( PDOException $e ) {
			echo ('Error establishing Connection');
			exit ();
		}
	}
	
	//For database :
	public function  getAllCustomers(){
		$stmt = $this->DB->prepare ("SELECT * FROM customers ORDER BY name DESC;");
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	
	public function  getAllEmployees(){
		$stmt = $this->DB->prepare ("SELECT * FROM employees ORDER BY name DESC;");
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	
	public function  getAllPurchase(){
		$stmt = $this->DB->prepare ("SELECT * FROM purchase ORDER BY purchase_date DESC;");
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	
	public function  getAllInventory(){
		$stmt = $this->DB->prepare ("SELECT * FROM inventory ORDER BY name DESC;");
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	
	
	public function getOrder($from_date, $to_date){
		$stmt = $this->DB->prepare ("SELECT * FROM orders WHERE due >= '".$from_date."' AND due <= '".$to_date."';");
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	
	// search method
	public function searchCustomer($customerName){
		$stmt = $this->DB->prepare ("SELECT * FROM customers WHERE name LIKE '%".$customerName."%';");
		$stmt -> bindParam ('customerName',$customerName);
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	public function searchEmployee($employeeName){
		$stmt = $this->DB->prepare ("SELECT * FROM employees WHERE name LIKE '%".$employeeName."%';");
		$stmt -> bindParam ('employeeName',$employeeName);
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	public function searchPurchase($purchaseName){
		$stmt = $this->DB->prepare ("SELECT * FROM purchase WHERE name LIKE '%".$purchaseName."%';");
		$stmt -> bindParam ('purchaseName',$purchaseName);
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	public function searchInventory($inventoryName){
		$stmt = $this->DB->prepare ("SELECT * FROM inventory WHERE name LIKE '%".$inventoryName."%';");
		$stmt -> bindParam ('inventoryName',$inventoryName);
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	
	
	
	//For database users:
	
	//verify whether the password match the username.
	public function verifyCredentials($userName, $psw){
		$Status = false;
		$stmt = $this->DB->prepare ("SELECT hash FROM users WHERE username='".$userName."'");
		$stmt -> bindParam ('userName',$id);
		$stmt -> bindParam ('id',$id);
		$stmt->execute ();
		$passwordArray = $stmt->fetchAll ( PDO::FETCH_ASSOC );
		if (count($passwordArray)>0){
			foreach ($passwordArray as $result){
				$hash_pwd=$result["hash"];
			}
			$loginStatus =  password_verify($psw, $hash_pwd);
		}
		return $loginStatus;
	}
	//check if the user is already exist.
	public function userCheck($username){
		$stmt = $this->DB->prepare ( "SELECT * FROM users WHERE username='".$username."'");
		$stmt -> bindParam ('username',$username);
		$stmt->execute ();
		$check = $stmt->fetchAll ( PDO::FETCH_ASSOC );
		$exist=!$check;
		return $exist;
	}
	//if it can register add user to database.
	public function addUser ($username, $password) {
		$stmt = $this->DB->prepare("INSERT INTO users (username, hash) values('".$username."','".$password."')");
		$stmt -> bindParam ('username',$username);
		$stmt -> bindParam ('password',$password);
		$stmt->execute();
	}
	
	//Get one movie's actors:
	
	
	// insert one customer info into the database
	public function insertCustomer($name, $company, $title, $phone_no, $email, $address){
		$stmt=$this->DB->prepare("INSERT INTO customers(name,company,title,phone_no,email,address) values
				(:name, :company, :title, :phone_no, :email, :address)");
		$stmt -> bindParam (':name',$name);
		$stmt -> bindParam (':company',$company);
		$stmt -> bindParam (':title',$title);
		$stmt -> bindParam (':phone_no',$phone_no);
		$stmt -> bindParam (':email',$email);
		$stmt -> bindParam (':address',$address);
		$stmt->execute ();
	}
	
	public function insertEmployee($name, $department, $position, $phone_no, $email, $address){
		$stmt=$this->DB->prepare("INSERT INTO employees(name,department,position,phone_no,email,address) values
				(:name, :department, :position, :phone_no, :email, :address)");
		$stmt -> bindParam (':name',$name);
		$stmt -> bindParam (':department',$department);
		$stmt -> bindParam (':position',$position);
		$stmt -> bindParam (':phone_no',$phone_no);
		$stmt -> bindParam (':email',$email);
		$stmt -> bindParam (':address',$address);
		$stmt->execute ();
	}
	
	public function insertOrder($name, $quantity, $price, $total, $due, $build, $ship, $color){
		$stmt=$this->DB->prepare("INSERT INTO orders(name,quantity,price,total,due,build,ship,color) values
				(:name, :quantity, :price, :total, :due, :build, :ship, :color)");
		$stmt -> bindParam (':name',$name);
		$stmt -> bindParam (':quantity',$quantity);
		$stmt -> bindParam (':price', $price);
		$stmt -> bindParam (':total', $total);
		$stmt -> bindParam (':due',$due);
		$stmt -> bindParam (':build',$build);
		$stmt -> bindParam (':ship',$ship);
		$stmt -> bindParam (':color',$color);
		$stmt->execute ();
	}
	
	public function insertPurchase($name, $purchase_date, $quantity, $price, $total, $status){
		$stmt=$this->DB->prepare("INSERT INTO purchase(name,purchase_date,quantity,price,total,status) values
				(:name, :purchase_date, :quantity, :price, :total, :status)");
		$stmt -> bindParam (':name',$name);
		$stmt -> bindParam (':quantity',$quantity);
		$stmt -> bindParam (':purchase_date',$purchase_date);
		$stmt -> bindParam (':price',$price);
		$stmt -> bindParam (':total',$total);
		$stmt -> bindParam (':status',$status);
		$stmt->execute ();
	}
	
	public function insertInventory($name, $quantity, $color, $area, $notes){
		$stmt=$this->DB->prepare("INSERT INTO inventory(name,quantity,color,area,notes) values
				(:name, :quantity, :color, :area, :notes)");
		$stmt -> bindParam (':name',$name);
		$stmt -> bindParam (':quantity',$quantity);
		$stmt -> bindParam (':color',$color);
		$stmt -> bindParam (':area',$area);
		$stmt -> bindParam (':notes',$notes);
		$stmt->execute ();
	}
	
	public function increaseInventory($num,$name){
		$stmt=$this->DB->prepare("UPDATE inventory SET quantity=quantity+'".$num."'WHERE name='".$name."'");
		$stmt->execute ();
	}
	
	
	
} // End class DatabaseAdaptor

$theDBA = new DatabaseAdaptor ();
//$arr=$theDBA -> searchMovie('A');
//$str = $array;
//for($i=1;$i<count($array);$i++){
	//if($array[$i]['name']!=$array[$i-1]['name']){
		//$str .= '<br>'.$array[$i]['name']."<br>";
	//}
	//$str .= '&nbsp&nbsp&nbsp&nbsp'.$array[$i]['first_name'].' '.$array[$i]['last_name'].'---'.$array[$i]['role'].'<br>';
//}
//print_r($arr[0]['name']);

?>

