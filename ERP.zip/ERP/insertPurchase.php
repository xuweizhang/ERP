<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert Purchase</title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>

<?php 
session_start ();
if (isset($_SESSION['username'])) {
	$username= $_SESSION['username'];
}


?>

<a href="purchase.php" class="returnHome"><code>Back</code></a>
<div class="insertBox">
<form action="controller.php" method="post" id="form1">
<label>Item Name:</label>
<input type="text" name="name"><br>
<label>Order Date:</label>
<input type="date" name="purchase_date"><br>
<label>Quantity:</label>
<input type="number" name="quantity"><br>
<label>Price:</label>
<input type="text" name="price"><br>
<label>Status:</label>
<label></label><input type="radio" name="status" value="Not Received">Not Received<br>
<label></label><input type="radio" name="status" value="Received">Received<br>
<input class="submitButton" type="submit" name="insertPurchase" value="Insert">
</form>
</div>

</body>
</html>

